@echo off
cd /d "%~dp0"
py -3 -m pip install -r requirements.txt
if errorlevel 1 (
  echo Python kurulumu veya paket yukleme basarisiz.
  pause
  exit /b 1
)
py -3 chess_arena.py
if errorlevel 1 pause
