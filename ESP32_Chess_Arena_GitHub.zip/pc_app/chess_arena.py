import queue
import logging
from pathlib import Path
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime

import chess
import chess.pgn
import serial
from serial.tools import list_ports

LIGHT = '#EEEED2'
DARK = '#769656'
HIGHLIGHT = '#F6F669'
PIECE_POINTS = {chess.PAWN: 1, chess.KNIGHT: 3, chess.BISHOP: 3, chess.ROOK: 5, chess.QUEEN: 9, chess.KING: 0}

PIECES = {
    'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
    'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟',
}


class ChessArena:
    def __init__(self, root):
        self.root = root
        root.title('ESP32 Chess Arena | N8R2 vs N16R8')
        root.geometry('940x720')
        root.minsize(820, 620)
        self.board = chess.Board()
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.worker = None
        self.last_move = None
        self.moves = []
        self.white_device = None
        self.black_device = None
        self.port_n8 = tk.StringVar()
        self.port_n16 = tk.StringVar()
        self.white_choice = tk.StringVar(value='N8R2')
        self.think_ms = tk.StringVar(value='3000')
        self.reply_timeout_ms = tk.StringVar(value='90000')
        self.log_dir = Path(__file__).resolve().parent / 'logs'
        self.log_dir.mkdir(exist_ok=True)
        self.log_path = self.log_dir / ('arena_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.log')
        self.logger = logging.getLogger('chess_arena_' + str(id(self)))
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(self.log_path, encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
        self.logger.addHandler(handler)
        self.status = tk.StringVar(value='Hazır — portları seçip oyunu başlatın.')
        self.white_score = tk.StringVar()
        self.black_score = tk.StringVar()
        self.result_text = tk.StringVar(value='Maç henüz başlamadı.')
        self.make_ui()
        self.refresh_ports()
        self.root.after(100, self.process_events)
        self.root.protocol('WM_DELETE_WINDOW', self.close)

    def make_ui(self):
        # Tüm arayüzü dikey kaydırılabilir alana yerleştir.
        # Satranç tahtası için kullanılan self.canvas bundan bağımsızdır.
        scroll_container = ttk.Frame(self.root)
        scroll_container.pack(fill='both', expand=True)
        self.page_canvas = tk.Canvas(scroll_container, highlightthickness=0, borderwidth=0)
        self.page_scrollbar = ttk.Scrollbar(
            scroll_container, orient='vertical', command=self.page_canvas.yview
        )
        self.page_canvas.configure(yscrollcommand=self.page_scrollbar.set)
        self.page_scrollbar.pack(side='right', fill='y')
        self.page_canvas.pack(side='left', fill='both', expand=True)

        outer = ttk.Frame(self.page_canvas, padding=14)
        self.page_window = self.page_canvas.create_window(
            (0, 0), window=outer, anchor='nw'
        )
        outer.bind(
            '<Configure>',
            lambda event: self.page_canvas.configure(
                scrollregion=self.page_canvas.bbox('all')
            )
        )
        self.page_canvas.bind(
            '<Configure>',
            lambda event: self.page_canvas.itemconfigure(
                self.page_window, width=event.width
            )
        )
        # Windows: tekerlek; Linux: Button-4 / Button-5.
        self.page_canvas.bind('<Enter>', self.enable_page_scroll)
        self.page_canvas.bind('<Leave>', self.disable_page_scroll)
        ttk.Label(outer, text='ESP32 CHESS ARENA', font=('Segoe UI', 20, 'bold')).pack(anchor='w', pady=(0, 12))
        top = ttk.LabelFrame(outer, text='Bağlantı ve oyun ayarları', padding=10)
        top.pack(fill='x')
        for i in range(6):
            top.columnconfigure(i, weight=1)
        ttk.Label(top, text='ESP32-S3 N8R2 portu').grid(row=0, column=0, sticky='w')
        ttk.Label(top, text='ESP32-S3 N16R8 portu').grid(row=0, column=2, sticky='w')
        ttk.Label(top, text='Beyaz oynayacak kart').grid(row=0, column=4, sticky='w')
        self.n8_combo = ttk.Combobox(top, textvariable=self.port_n8, state='readonly', width=15)
        self.n8_combo.grid(row=1, column=0, columnspan=2, sticky='ew', padx=(0, 10), pady=5)
        self.n16_combo = ttk.Combobox(top, textvariable=self.port_n16, state='readonly', width=15)
        self.n16_combo.grid(row=1, column=2, columnspan=2, sticky='ew', padx=(0, 10), pady=5)
        self.color_combo = ttk.Combobox(top, textvariable=self.white_choice, state='readonly', values=['N8R2', 'N16R8'], width=13)
        self.color_combo.grid(row=1, column=4, columnspan=2, sticky='ew', pady=5)
        ttk.Label(top, text='Hamle başına düşünme süresi (ms)').grid(row=2, column=0, columnspan=2, sticky='w')
        ttk.Label(top, text='ESP32 cevap bekleme sınırı (ms)').grid(row=2, column=2, columnspan=2, sticky='w')
        self.think_entry = ttk.Entry(top, textvariable=self.think_ms, width=12)
        self.think_entry.grid(row=3, column=0, sticky='w', pady=5)
        self.timeout_entry = ttk.Entry(top, textvariable=self.reply_timeout_ms, width=12)
        self.timeout_entry.grid(row=3, column=2, sticky='w', pady=5)
        self.refresh_btn = ttk.Button(top, text='Portları yenile', command=self.refresh_ports)
        self.refresh_btn.grid(row=4, column=2, sticky='ew', padx=5)
        self.start_btn = ttk.Button(top, text='▶ Oyunu başlat', command=self.start)
        self.start_btn.grid(row=4, column=3, sticky='ew', padx=5)
        self.stop_btn = ttk.Button(top, text='■ Durdur', command=self.stop, state='disabled')
        self.stop_btn.grid(row=4, column=4, sticky='ew', padx=5)
        self.save_btn = ttk.Button(top, text='PGN kaydet', command=self.save_pgn)
        self.save_btn.grid(row=4, column=5, sticky='ew', padx=5)

        body = ttk.Frame(outer)
        body.pack(fill='both', expand=True, pady=12)
        board_wrap = ttk.Frame(body)
        board_wrap.pack(side='left', fill='both', expand=True)
        self.canvas = tk.Canvas(board_wrap, width=544, height=544, highlightthickness=0, bg='#252525')
        self.canvas.pack(anchor='nw')
        side = ttk.Frame(body, width=290)
        side.pack(side='right', fill='both', expand=True, padx=(12, 0))
        score_frame = ttk.LabelFrame(side, text='TAŞ PUANLARI', padding=8)
        score_frame.pack(fill='x', pady=(0, 10))
        ttk.Label(score_frame, textvariable=self.white_score, font=('Segoe UI', 11, 'bold')).pack(anchor='w')
        ttk.Label(score_frame, textvariable=self.black_score, font=('Segoe UI', 11, 'bold')).pack(anchor='w', pady=(3, 0))
        ttk.Label(score_frame, text='Piyon 1 · At 3 · Fil 3 · Kale 5 · Vezir 9', font=('Segoe UI', 8)).pack(anchor='w', pady=(5, 0))
        result_frame = ttk.LabelFrame(side, text='MAÇ SONUCU', padding=8)
        result_frame.pack(fill='x', pady=(0, 10))
        ttk.Label(result_frame, textvariable=self.result_text, font=('Segoe UI', 11, 'bold'), wraplength=260).pack(anchor='w')
        ttk.Label(side, text='HAMLE GEÇMİŞİ', font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        self.move_text = tk.Text(side, height=14, width=35, state='disabled', font=('Consolas', 11))
        self.move_text.pack(fill='both', expand=True, pady=(6, 12))
        ttk.Label(side, text='CİHAZ MESAJLARI', font=('Segoe UI', 12, 'bold')).pack(anchor='w')
        self.log_text = tk.Text(side, height=10, width=35, state='disabled', font=('Consolas', 9))
        self.log_text.pack(fill='both', expand=True, pady=(6, 0))
        ttk.Label(outer, textvariable=self.status, font=('Segoe UI', 11)).pack(fill='x', anchor='w')
        self.update_scores()
        self.draw_board()

    def enable_page_scroll(self, event=None):
        self.root.bind_all('<MouseWheel>', self.on_page_mousewheel)
        self.root.bind_all('<Button-4>', self.on_page_mousewheel)
        self.root.bind_all('<Button-5>', self.on_page_mousewheel)

    def disable_page_scroll(self, event=None):
        self.root.unbind_all('<MouseWheel>')
        self.root.unbind_all('<Button-4>')
        self.root.unbind_all('<Button-5>')

    def on_page_mousewheel(self, event):
        # Metin alanları üzerindeyken kendi iç kaydırmalarını koru.
        if isinstance(event.widget, (tk.Text, ttk.Combobox)):
            return
        if getattr(event, 'num', None) == 4:
            direction = -1
        elif getattr(event, 'num', None) == 5:
            direction = 1
        else:
            direction = -1 if event.delta > 0 else 1
        self.page_canvas.yview_scroll(direction, 'units')

    def update_scores(self):
        # Alınan taşların standart maddi değeri: başlangıç materyali - tahtadaki materyal.
        def material(color):
            return sum(len(self.board.pieces(pt, color)) * value for pt, value in PIECE_POINTS.items())
        white_taken = 39 - material(chess.BLACK)
        black_taken = 39 - material(chess.WHITE)
        difference = white_taken - black_taken
        self.white_score.set(f'⚪ Beyaz ({self.white_device or chr(63)}): {white_taken} puan' + (f'  (+{difference})' if difference > 0 else ''))
        self.black_score.set(f'⚫ Siyah ({self.black_device or chr(63)}): {black_taken} puan' + (f'  (+{-difference})' if difference < 0 else ''))

    def refresh_ports(self):
        ports = [p.device for p in list_ports.comports()]
        self.n8_combo['values'] = ports
        self.n16_combo['values'] = ports
        if self.port_n8.get() not in ports:
            self.port_n8.set(ports[0] if ports else '')
        if self.port_n16.get() not in ports:
            self.port_n16.set(ports[1] if len(ports) > 1 else '')

    def draw_board(self):
        c = self.canvas
        c.delete('all')
        size = 64
        margin = 25
        for row in range(8):
            for col in range(8):
                sq = chess.square(col, 7 - row)
                color = LIGHT if (row + col) % 2 == 0 else DARK
                if self.last_move and sq in (self.last_move.from_square, self.last_move.to_square):
                    color = HIGHLIGHT
                x0, y0 = margin + col * size, margin + row * size
                c.create_rectangle(x0, y0, x0 + size, y0 + size, fill=color, outline=color)
                piece = self.board.piece_at(sq)
                if piece:
                    symbol = PIECES[piece.symbol()]
                    c.create_text(x0 + size / 2, y0 + size / 2, text=symbol,
                                  font=('Segoe UI Symbol', 42), fill='#161616' if piece.color == chess.BLACK else '#FFFFFF')
        for col in range(8):
            c.create_text(margin + col * size + size / 2, 537, text='abcdefgh'[col], fill='white')
        for row in range(8):
            c.create_text(12, margin + row * size + size / 2, text=str(8 - row), fill='white')

    def log(self, msg):
        self.logger.info(msg)
        self.log_text.config(state='normal')
        self.log_text.insert('end', msg + '\n')
        self.log_text.see('end')
        self.log_text.config(state='disabled')

    def show_moves(self):
        self.move_text.config(state='normal')
        self.move_text.delete('1.0', 'end')
        for i in range(0, len(self.moves), 2):
            white = self.moves[i]
            black = self.moves[i + 1] if i + 1 < len(self.moves) else ''
            self.move_text.insert('end', f'{i // 2 + 1:>3}. {white:<9} {black}\n')
        self.move_text.config(state='disabled')
        self.move_text.see('end')

    def set_running(self, running):
        for widget in (self.n8_combo, self.n16_combo, self.color_combo, self.think_entry, self.timeout_entry, self.refresh_btn):
            widget.config(state='disabled' if running else ('readonly' if isinstance(widget, ttk.Combobox) else 'normal'))
        self.start_btn.config(state='disabled' if running else 'normal')
        self.stop_btn.config(state='normal' if running else 'disabled')

    def start(self):
        a, b = self.port_n8.get(), self.port_n16.get()
        if not a or not b or a == b:
            messagebox.showerror('Port hatası', 'İki farklı COM portu seçmelisin.')
            return
        try:
            ms = int(self.think_ms.get())
            timeout_ms = int(self.reply_timeout_ms.get())
            if not 500 <= ms <= 60000 or not 15000 <= timeout_ms <= 900000 or timeout_ms <= ms:
                raise ValueError()
        except ValueError:
            messagebox.showerror('Süre hatası', 'Düşünme: 500–60000 ms; cevap bekleme: 15000–900000 ms ve düşünme süresinden uzun olmalı.')
            return
        self.board.reset()
        self.moves.clear()
        self.last_move = None
        self.result_text.set('Maç devam ediyor...')
        self.draw_board()
        self.show_moves()
        self.stop_event.clear()
        self.set_running(True)
        self.white_device = self.white_choice.get()
        self.black_device = 'N16R8' if self.white_device == 'N8R2' else 'N8R2'
        self.update_scores()
        self.status.set(f'Bağlanıyor: Beyaz {self.white_device} / Siyah {self.black_device}')
        self.worker = threading.Thread(target=self.run_game, args=(a, b, ms, timeout_ms / 1000), daemon=True)
        self.worker.start()

    def stop(self):
        self.stop_event.set()
        self.status.set('Durdurma istendi; hesaplama tamamlanınca duracak...')

    def serial_command(self, device, command):
        device.reset_input_buffer()
        device.write((command + '\n').encode('ascii'))
        device.flush()

    def wait_reply(self, device, prefixes, timeout, device_name='ESP32', port='', ply=None):
        started = time.monotonic()
        deadline = started + timeout
        last_warning = 0
        last_diagnostic = ''
        while time.monotonic() < deadline and not self.stop_event.is_set():
            raw = device.readline()
            if raw:
                line = raw.decode('utf-8', errors='replace').strip()
                if line:
                    if line.startswith(tuple(prefixes)):
                        elapsed = time.monotonic() - started
                        self.events.put(('log', f'{device_name} ({port}): yanıt {elapsed:.1f} sn içinde alındı'))
                        return line
                    if line.startswith('ERROR'):
                        raise RuntimeError(f'{device_name} ({port}): {line}')
                    last_diagnostic = line[:160]
                    self.logger.info('%s (%s) hamle %s seri: %s', device_name, port, ply, last_diagnostic)
            elapsed = time.monotonic() - started
            if elapsed >= 10 and elapsed - last_warning >= 10:
                last_warning = elapsed
                self.events.put(('status', f'{device_name} ({port}) yanıt bekleniyor: {elapsed:.0f}/{timeout:.0f} sn | hamle {ply}'))
                self.events.put(('log', f'UYARI: {device_name} ({port}) {elapsed:.0f} sn yanıt vermedi (hamle {ply})'))
        if self.stop_event.is_set():
            raise InterruptedError('Oyun durduruldu')
        raise TimeoutError(f'{device_name} ({port}) {timeout:.0f} saniyede cevap vermedi; hamle {ply}. '
                           f'Son seri mesaj: {last_diagnostic or "yok"}. '
                           f'Log: {self.log_path}')

    def run_game(self, port_n8, port_n16, think_ms, reply_timeout):
        devices = {}
        try:
            for name, port in [('N8R2', port_n8), ('N16R8', port_n16)]:
                devices[name] = serial.Serial(port, baudrate=115200, timeout=0.2, write_timeout=2)
                self.events.put(('log', f'{name}: {port} bağlandı'))
            # Opening serial can reset the ESP32. Give both boards time to boot.
            time.sleep(2.5)
            for name, dev in devices.items():
                self.serial_command(dev, 'PING')
                self.wait_reply(dev, ['PONG'], 8, name, dev.port)
                self.serial_command(dev, f'TIME {think_ms}')
                self.wait_reply(dev, ['TIME_OK'], 8, name, dev.port)
                self.events.put(('log', f'{name}: hazır'))
            self.events.put(('status', 'Maç başladı. İlk 20 yarım hamlede dengeli açılış çeşitliliği etkin.'))
            board = chess.Board()
            for ply in range(500):
                if self.stop_event.is_set():
                    break
                if board.is_game_over(claim_draw=True):
                    break
                name = self.white_device if board.turn == chess.WHITE else self.black_device
                dev = devices[name]
                self.events.put(('status', f'{name} ({"Beyaz" if board.turn else "Siyah"}) düşünüyor...' + (' | Dengeli açılış' if ply < 20 else '')))
                self.serial_command(dev, (f'GOX {ply} ' if ply < 20 else 'GO ') + board.fen())
                response = self.wait_reply(dev, ['MOVE ', 'NOMOVE'], reply_timeout, name, dev.port, ply + 1)
                if response == 'NOMOVE':
                    raise RuntimeError(f'{name}: motor hamle bulamadı')
                uci = response[5:].strip()
                try:
                    move = chess.Move.from_uci(uci)
                except ValueError:
                    raise RuntimeError(f'{name} geçersiz UCI döndürdü: {uci}')
                if move not in board.legal_moves:
                    raise RuntimeError(f'{name} kurallara aykırı hamle gönderdi: {uci} | {board.fen()}')
                san = board.san(move)
                board.push(move)
                self.events.put(('move', (uci, san, name)))
                self.events.put(('log', f'{name}: {san} ({uci})'))
            if self.stop_event.is_set():
                self.events.put(('result', 'Maç durduruldu — kazanan yok.'))
                self.events.put(('status', 'Oyun durduruldu.'))
            elif board.is_game_over(claim_draw=True):
                outcome = board.outcome(claim_draw=True)
                reason = {
                    chess.Termination.CHECKMATE: 'Şah mat',
                    chess.Termination.STALEMATE: 'Pat',
                    chess.Termination.INSUFFICIENT_MATERIAL: 'Yetersiz materyal',
                    chess.Termination.FIFTY_MOVES: '50 hamle kuralı',
                    chess.Termination.THREEFOLD_REPETITION: 'Üç kez konum tekrarı',
                    chess.Termination.FIVEFOLD_REPETITION: 'Beş kez konum tekrarı',
                    chess.Termination.SEVENTYFIVE_MOVES: '75 hamle kuralı',
                }.get(outcome.termination, outcome.termination.name)
                if outcome.winner is None:
                    result = f'BERABERE — {reason} (½–½)'
                else:
                    winner = self.white_device if outcome.winner == chess.WHITE else self.black_device
                    result = f'KAZANAN: {winner} ({"Beyaz" if outcome.winner else "Siyah"}) — {reason}'
                self.events.put(('result', result))
                self.events.put(('status', f'Oyun bitti: {result}'))
            else:
                self.events.put(('result', 'Sonuçsuz: 500 yarım hamle sınırı'))
                self.events.put(('status', '500 yarım hamle sınırına ulaşıldı.'))
        except InterruptedError:
            self.events.put(('result', 'Maç durduruldu — kazanan yok.'))
            self.events.put(('status', 'Oyun durduruldu.'))
        except Exception as e:
            self.events.put(('result', 'Maç tamamlanamadı — kazanan belirlenmedi.'))
            self.events.put(('status', f'Hata: {e}'))
            self.events.put(('log', f'HATA: {e}'))
            self.logger.exception('Maç durdu: %s', e)
        finally:
            for dev in devices.values():
                try:
                    dev.close()
                except Exception:
                    pass
            self.events.put(('finished', None))

    def process_events(self):
        try:
            while True:
                event, data = self.events.get_nowait()
                if event == 'move':
                    uci, san, _ = data
                    move = chess.Move.from_uci(uci)
                    self.board.push(move)
                    self.last_move = move
                    self.moves.append(san)
                    self.draw_board()
                    self.show_moves()
                    self.update_scores()
                elif event == 'log':
                    self.log(data)
                elif event == 'status':
                    self.status.set(data)
                elif event == 'result':
                    self.result_text.set(data)
                    self.log('SONUÇ: ' + data)
                    if data.startswith('KAZANAN:') or data.startswith('BERABERE'):
                        messagebox.showinfo('ESP32 Chess Arena — Maç Sonucu', data)
                elif event == 'finished':
                    self.set_running(False)
        except queue.Empty:
            pass
        self.root.after(100, self.process_events)

    def save_pgn(self):
        if not self.board.move_stack:
            messagebox.showinfo('PGN', 'Henüz kaydedilecek hamle yok.')
            return
        path = filedialog.asksaveasfilename(defaultextension='.pgn', filetypes=[('PGN dosyası', '*.pgn')],
                                            initialfile='esp32_mac_' + datetime.now().strftime('%Y%m%d_%H%M') + '.pgn')
        if not path:
            return
        game = chess.pgn.Game()
        game.headers['Event'] = 'ESP32 Chess Arena'
        game.headers['White'] = self.white_device or 'ESP32 White'
        game.headers['Black'] = self.black_device or 'ESP32 Black'
        game.headers['Date'] = datetime.now().strftime('%Y.%m.%d')
        game.headers['Result'] = self.board.result(claim_draw=True) if self.board.is_game_over(claim_draw=True) else '*'
        node = game
        for move in self.board.move_stack:
            node = node.add_variation(move)
        with open(path, 'w', encoding='utf-8') as f:
            print(game, file=f)
        self.log(f'PGN kaydedildi: {path}')

    def close(self):
        self.stop_event.set()
        for handler in self.logger.handlers[:]:
            handler.flush()
            handler.close()
            self.logger.removeHandler(handler)
        self.root.destroy()


if __name__ == '__main__':
    root = tk.Tk()
    try:
        style = ttk.Style(root)
        if 'vista' in style.theme_names():
            style.theme_use('vista')
    except Exception:
        pass
    ChessArena(root)
    root.mainloop()
