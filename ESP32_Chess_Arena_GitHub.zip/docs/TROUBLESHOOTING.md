# Sorun giderme

## COM portu açılamıyor / `PermissionError(13)`

Arduino Seri Monitör'ü ve COM portunu kullanan diğer uygulamaları kapatın. USB kablosunu ve Aygıt Yöneticisi'ndeki port numarasını kontrol edin.

## 90 saniye yanıt gelmiyor

Bu sorun yalnızca zaman aşımı değerini artırarak çözülmeyebilir. `pc_app/logs/` altındaki log dosyasını inceleyin. Son `Depth` satırları motorun hesaplamaya başladığını gösterebilir; hiç tanılama mesajı olmaması komutun işlenmediğini kesin olarak kanıtlamaz.

## Seri Monitör'den test

Python uygulamasını kapatın. 115200 baud ve Newline seçin:

```text
PING
TIME 3000
GO rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1
```

Sırasıyla `PONG`, `TIME_OK`, ardından `MOVE ...` yanıtları beklenir. Gerçek hamle değişebilir.

## Maç kaydı ve loglar

Uygulama logları `pc_app/logs/` içine kaydeder. PGN dosyası arayüzden dışa aktarılır. Loglarda yerel kullanıcı klasör yolları olabileceği için GitHub'a yüklemeden önce kontrol edin.
